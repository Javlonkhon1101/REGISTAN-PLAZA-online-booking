<?php
// To
define("WEBMASTER_EMAIL", 'email@companyname.com');
?>